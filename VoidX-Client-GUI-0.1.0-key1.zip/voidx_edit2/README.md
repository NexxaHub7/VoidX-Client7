# VoidX Client 0.1.0 — Performance Update

Fabric 1.21.11 client-side utilities.

## Performance
- FPS Stabilizer: reacts to sustained FPS pressure by lowering render distance and recovers slowly.
- Entity Distance: uses a reduced entity render-distance scale while the boost is active.
- Particle Manager: keeps particles at Minimal while enabled.
- Progressive Chunks: ramps render distance from 4 to 6 gradually to reduce sudden chunk-load spikes.
- Existing VoidX GUI: cyan theme, centered panel, custom tabs, scroll, borders and lightweight effects.

All options are client-side and configurable from the Rendimiento tab.

## Build
This archive does not include a Gradle wrapper. Use a local Gradle/Fabric Loom environment compatible with the project settings.
