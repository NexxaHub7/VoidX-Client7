package com.luiscript.boxpvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class BoxPvpClient implements ClientModInitializer {

    private static KeyMapping menuKey;   // tecla por defecto: 1 (configurable en Key Binds > BoxPvP Utils)

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft = false;
    private boolean lastRight = false;
    private Integer savedLimit = null;

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    @Override
    public void onInitializeClient() {
        BoxConfig.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("boxpvp_utils", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_1, category));

        ClientTickEvents.START_CLIENT_TICK.register(this::fireworkFixed);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register(this::render);
    }

    // ---------- Firework Fixed ----------
    private void fireworkFixed(Minecraft mc) {
        if (!BoxConfig.fireworkFix || mc.player == null || mc.gameMode == null || mc.screen != null) return;
        if (!mc.player.isFallFlying()) return;

        InteractionHand hand = null;
        if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).is(Items.FIREWORK_ROCKET)) {
            hand = InteractionHand.MAIN_HAND;
        } else if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).isEmpty()
                && mc.player.getItemInHand(InteractionHand.OFF_HAND).is(Items.FIREWORK_ROCKET)) {
            hand = InteractionHand.OFF_HAND;
        }
        if (hand == null) return;

        // Cada clic derecho = un impulso en el aire (nunca se lanza contra un bloque)
        while (mc.options.keyUse.consumeClick()) {
            mc.gameMode.useItem(mc.player, hand);
            mc.player.swing(hand);
        }
        mc.options.keyUse.setDown(false);
    }

    // ---------- Tick ----------
    private void tick(Minecraft mc) {
        while (menuKey.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new BoxMenuScreen());
        }

        FpsBoost.sync(mc);

        if (BoxConfig.noParticles && mc.level != null) {
            mc.particleEngine.clearParticles();
        }

        // Ventana sin foco -> pocos FPS; al volver (o al apagar la opcion) se restaura
        OptionInstance<Integer> limit = mc.options.framerateLimit();
        boolean throttle = BoxConfig.bgThrottle && !mc.isWindowActive();
        if (throttle && savedLimit == null) {
            savedLimit = limit.get();
            limit.set(30);
        } else if (!throttle && savedLimit != null) {
            limit.set(savedLimit);
            savedLimit = null;
        }

        // CPS
        long now = System.currentTimeMillis();
        boolean left = mc.options.keyAttack.isDown();
        boolean right = mc.options.keyUse.isDown();
        if (mc.screen == null) {
            if (left && !lastLeft) leftClicks.addLast(now);
            if (right && !lastRight) rightClicks.addLast(now);
        }
        lastLeft = left;
        lastRight = right;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.removeFirst();
    }

    // ---------- HUD ----------
    private void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (!BoxConfig.hud || mc.player == null || mc.options.hideGui) return;

        int x = 6;
        int y = 6;
        int white = 0xFFFFFFFF;

        if (BoxConfig.cps) {
            g.drawString(mc.font, "CPS: " + leftClicks.size() + " | " + rightClicks.size(), x, y, white);
            y += 11;
        }
        if (BoxConfig.fps) {
            g.drawString(mc.font, "FPS: " + mc.getFps(), x, y, white);
            y += 11;
        }
        if (BoxConfig.ping) {
            PlayerInfo info = mc.getConnection() != null
                    ? mc.getConnection().getPlayerInfo(mc.player.getUUID()) : null;
            if (info != null) {
                g.drawString(mc.font, "Ping: " + info.getLatency() + " ms", x, y, white);
                y += 11;
            }
        }
        if (BoxConfig.armor) {
            y += 4;
            for (EquipmentSlot slot : ARMOR) {
                ItemStack stack = mc.player.getItemBySlot(slot);
                if (stack.isEmpty()) continue;
                g.renderItem(stack, x, y);
                if (stack.isDamageableItem()) {
                    int left = stack.getMaxDamage() - stack.getDamageValue();
                    int color = left < stack.getMaxDamage() * 0.2 ? 0xFFFF5555 : white;
                    g.drawString(mc.font, String.valueOf(left), x + 20, y + 4, color);
                }
                y += 18;
            }
        }
    }
}
