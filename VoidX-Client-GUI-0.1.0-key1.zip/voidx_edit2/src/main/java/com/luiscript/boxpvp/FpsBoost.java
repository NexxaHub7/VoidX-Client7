package com.luiscript.boxpvp;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsPreset;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

import java.util.LinkedHashMap;
import java.util.Map;

public final class FpsBoost {

    // ---- Ajusta aqui si quieres ver mas o menos lejos ----
    private static final int RENDER_DISTANCE = 6;
    private static final int SIMULATION_DISTANCE = 5;
    private static final int STABLE_MIN_RENDER = 4;
    private static final int STABLE_TARGET_RENDER = 6;
    // ------------------------------------------------------

    private static final Map<OptionInstance<?>, Object> BACKUP = new LinkedHashMap<>();
    private static boolean applied = false;
    private static int adaptiveRender = STABLE_TARGET_RENDER;
    private static int healthyTicks = 0;
    private static int pressureTicks = 0;
    private static int rampTicks = 0;

    private FpsBoost() {}

    private static <T> void set(OptionInstance<T> opt, T value) {
        BACKUP.putIfAbsent(opt, opt.get());
        opt.set(value);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void restore() {
        for (Map.Entry<OptionInstance<?>, Object> e : BACKUP.entrySet()) {
            ((OptionInstance) e.getKey()).set(e.getValue());
        }
        BACKUP.clear();
    }

    /** Aplica o revierte los ajustes segun BoxConfig.boost. */
    public static void sync(Minecraft mc) {
        if (BoxConfig.boost != applied) {
            if (BoxConfig.boost) {
                apply(mc.options);
                adaptiveRender = STABLE_MIN_RENDER;
                healthyTicks = pressureTicks = rampTicks = 0;
            } else {
                restore();
            }
            applied = BoxConfig.boost;
        }

        if (BoxConfig.boost) adaptiveTick(mc);
    }

    private static void adaptiveTick(Minecraft mc) {
        if (mc.level == null) return;
        int fps = mc.getFps();
        pressureTicks = fps > 0 && fps < 35 ? pressureTicks + 1 : 0;
        healthyTicks = fps >= 52 ? healthyTicks + 1 : 0;

        // Lower distance quickly during a sustained drop; recover slowly to avoid chunk-load spikes.
        if (BoxConfig.fpsStabilizer && pressureTicks >= 12 && adaptiveRender > STABLE_MIN_RENDER) {
            adaptiveRender--;
            mc.options.renderDistance().set(adaptiveRender);
            pressureTicks = 0;
            healthyTicks = 0;
        } else if (BoxConfig.progressiveChunks && healthyTicks >= 80 && adaptiveRender < STABLE_TARGET_RENDER) {
            adaptiveRender++;
            mc.options.renderDistance().set(adaptiveRender);
            healthyTicks = 0;
        }

        if (BoxConfig.progressiveChunks) {
            rampTicks++;
            if (rampTicks == 20 && adaptiveRender < STABLE_TARGET_RENDER) {
                adaptiveRender = Math.max(adaptiveRender, STABLE_MIN_RENDER);
                mc.options.renderDistance().set(adaptiveRender);
                rampTicks = 0;
            }
        }
    }

    private static void apply(Options o) {
        // Distancias
        set(o.renderDistance(), BoxConfig.progressiveChunks || BoxConfig.fpsStabilizer ? STABLE_MIN_RENDER : RENDER_DISTANCE);
        set(o.simulationDistance(), SIMULATION_DISTANCE);
        set(o.entityDistanceScaling(), BoxConfig.entityDistance ? 0.5 : 1.0);

        // Graficos
        set(o.graphicsPreset(), GraphicsPreset.FAST);
        set(o.cloudStatus(), CloudStatus.OFF);
        set(o.particles(), BoxConfig.particleManager ? ParticleStatus.MINIMAL : ParticleStatus.ALL);
        set(o.ambientOcclusion(), false);

        // Sombras / calidad
        set(o.entityShadows(), false);
        set(o.biomeBlendRadius(), 0);
        set(o.mipmapLevels(), 0);

        // Framerate
        set(o.framerateLimit(), 260);
        set(o.enableVsync(), false);

        // Efectos
        set(o.bobView(), false);
        set(o.screenEffectScale(), 0.0);
        set(o.fovEffectScale(), 0.0);
        set(o.darknessEffectScale(), 0.0);
        set(o.damageTiltStrength(), 0.0);
        set(o.glintSpeed(), 0.0);
        set(o.glintStrength(), 0.0);
        set(o.hideLightningFlash(), true);
    }
}