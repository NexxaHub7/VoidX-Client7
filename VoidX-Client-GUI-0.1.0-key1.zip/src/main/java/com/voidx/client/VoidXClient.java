package com.voidx.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public final class VoidXClient implements ClientModInitializer {
    private static KeyMapping openMenu;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("voidx_client", "main"));

        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.voidx_client.menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_1,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(Minecraft mc) {
        while (openMenu.consumeClick()) {
            if (mc.screen == null) {
                mc.setScreen(new VoidXScreen());
            }
        }
    }
}
