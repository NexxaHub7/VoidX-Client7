package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class BoxMenuScreen extends Screen {
    private static final int WHITE = 0xFFF4F0FF;
    private static final int MUTED = 0xFFAAA3B8;
    private static final int CARD = 0xE61A1720;
    private static final int CARD_HOVER = 0xF3262030;
    private static final int GREEN = 0xFF65E6A5;
    private static final int RED = 0xFFFF6B7A;

    private int panelX, panelY, panelW, panelH;
    private int tab = 0;
    private int mouseX, mouseY;
    private static final String[] TABS = {"Inicio", "Rendimiento", "HUD", "Gui", "Utilidades", "Ajustes"};

    public BoxMenuScreen() {
        super(Component.literal("VoidX Client"));
    }

    @Override
    protected void init() {
        int baseW = 660 * BoxConfig.guiScale / 100;
        int baseH = 390 * BoxConfig.guiScale / 100;
        panelW = Math.min(baseW, this.width - 24);
        panelH = Math.min(baseH, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private int rainbow() {
        float h = (System.currentTimeMillis() % 6000L) / 6000.0f;
        float r = Math.abs(h * 6.0f - 3.0f) - 1.0f;
        float g = 2.0f - Math.abs(h * 6.0f - 2.0f);
        float b = 2.0f - Math.abs(h * 6.0f - 4.0f);
        int ri = (int) (Math.max(0, Math.min(1, r)) * 255);
        int gi = (int) (Math.max(0, Math.min(1, g)) * 255);
        int bi = (int) (Math.max(0, Math.min(1, b)) * 255);
        return 0xFF000000 | (ri << 16) | (gi << 8) | bi;
    }

    private int accent() {
        return BoxConfig.guiRainbow ? rainbow() : 0xFF9B4DFF;
    }

    private int panelColor() {
        int alpha = Math.max(55, Math.min(100, BoxConfig.guiOpacity)) * 255 / 100;
        return (alpha << 24) | 0x00080A0D;
    }

    private void drawPanel(GuiGraphics g) {
        int a = accent();
        if (BoxConfig.guiGlow) {
            g.fill(panelX - 3, panelY - 3, panelX + panelW + 3, panelY + panelH + 3, 0x449B4DFF);
            g.fill(panelX - 1, panelY - 1, panelX + panelW + 1, panelY + panelH + 1, 0x669B4DFF);
        }
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, panelColor());
        if (BoxConfig.guiBorder) {
            g.fill(panelX, panelY, panelX + panelW, panelY + 1, a);
            g.fill(panelX, panelY + panelH - 1, panelX + panelW, panelY + panelH, a);
            g.fill(panelX, panelY, panelX + 1, panelY + panelH, a);
            g.fill(panelX + panelW - 1, panelY, panelX + panelW, panelY + panelH, a);
        }

        int sideW = 154;
        g.fill(panelX + sideW, panelY + 1, panelX + sideW + 1, panelY + panelH - 1, 0xFF2A2432);

        // Lightweight decorative "art" made from Minecraft items; no external textures needed.
        ItemStack star = new ItemStack(Items.NETHER_STAR);
        g.renderItem(star, panelX + panelW - 42, panelY + 12);
        g.drawString(this.font, Component.literal("VOIDX"), panelX + 18, panelY + 17, WHITE);
        g.drawString(this.font, Component.literal("CLIENT"), panelX + 19, panelY + 30, a);
        g.drawString(this.font, Component.literal("KEY 1"), panelX + 101, panelY + 24, MUTED);

        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 58 + i * 40;
            boolean selected = tab == i;
            boolean hover = inside(mouseX, mouseY, panelX + 10, y, sideW - 20, 32);
            int bg = selected ? 0xCC5520A0 : hover ? 0x993A3044 : 0x66120F17;
            g.fill(panelX + 10, y, panelX + sideW - 10, y + 32, bg);
            if (selected) g.fill(panelX + 10, y, panelX + 13, y + 32, a);
            drawTabIcon(g, panelX + 25, y + 16, i, selected ? a : MUTED);
            g.drawString(this.font, Component.literal(TABS[i]), panelX + 40, y + 10, selected ? WHITE : MUTED);
        }

        g.drawString(this.font, Component.literal("VOIDX  •  1.1"), panelX + 17, panelY + panelH - 22, MUTED);
    }

    private void drawTabIcon(GuiGraphics g, int x, int y, int index, int color) {
        String icon = switch (index) {
            case 0 -> "◆";
            case 1 -> "⚡";
            case 2 -> "◇";
            case 3 -> "✦";
            case 4 -> "✚";
            default -> "⚙";
        };
        g.drawCenteredString(this.font, Component.literal(icon), x, y - 5, color);
    }

    private void title(GuiGraphics g, String name, String subtitle) {
        int x = panelX + 176;
        g.drawString(this.font, Component.literal(name), x, panelY + 20, WHITE);
        g.drawString(this.font, Component.literal(subtitle), x, panelY + 34, MUTED);
        g.fill(x, panelY + 47, x + panelW - 194, panelY + 48, 0xFF302638);
    }

    private void card(GuiGraphics g, int x, int y, int w, int h, String name, String desc, boolean active) {
        boolean hover = inside(mouseX, mouseY, x, y, w, h);
        int a = accent();
        g.fill(x, y, x + w, y + h, hover ? CARD_HOVER : CARD);
        g.fill(x, y, x + 3, y + h, active ? a : 0xFF3A3440);
        g.drawString(this.font, Component.literal(name), x + 13, y + 9, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 13, y + 23, MUTED);
        g.drawString(this.font, Component.literal(active ? "ON" : "OFF"), x + w - (active ? 28 : 34), y + 9, active ? GREEN : RED);
    }

    private void switchRow(GuiGraphics g, int y, String name, String desc, boolean value) {
        int x = panelX + 176;
        int w = panelW - 194;
        boolean hover = inside(mouseX, mouseY, x, y, w, 38);
        int a = accent();
        g.fill(x, y, x + w, y + 38, hover ? CARD_HOVER : CARD);
        g.fill(x, y, x + 2, y + 38, value ? a : 0xFF3A3440);
        g.drawString(this.font, Component.literal(name), x + 12, y + 7, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 12, y + 21, MUTED);
        int sx = x + w - 50;
        int sy = y + 10;
        g.fill(sx, sy, sx + 34, sy + 17, value ? a : 0xFF39343F);
        g.fill(value ? sx + 20 : sx + 3, sy + 3, value ? sx + 31 : sx + 14, sy + 14, WHITE);
    }

    private void drawHome(GuiGraphics g) {
        title(g, "Bienvenido a VoidX", "Panel flotante • fondo del mundo visible • controles propios");
        int x = panelX + 176;
        int y = panelY + 62;
        int a = accent();
        g.fill(x, y, x + panelW - 194, y + 76, 0xD9161020);
        g.fill(x, y, x + 4, y + 76, a);
        g.drawString(this.font, Component.literal("VOIDX"), x + 16, y + 14, a);
        g.drawString(this.font, Component.literal("PLAY DIFFERENT"), x + 16, y + 30, WHITE);
        g.drawString(this.font, Component.literal("Performance • HUD • GUI • Utilities"), x + 16, y + 50, MUTED);
        g.renderItem(new ItemStack(Items.ENDER_EYE), x + panelW - 226, y + 17);

        int cw = (panelW - 206) / 3;
        int cy = y + 90;
        card(g, x, cy, cw, 56, "FPS Boost", "Rendimiento", BoxConfig.boost);
        card(g, x + cw + 8, cy, cw, 56, "HUD", "Información", BoxConfig.hud);
        card(g, x + (cw + 8) * 2, cy, cw, 56, "GUI", "Personalización", true);
        g.drawString(this.font, Component.literal("Novedades"), x, cy + 78, a);
        g.drawString(this.font, Component.literal("Gui: escala, bordes, glow, opacity y rainbow."), x, cy + 94, MUTED);
    }

    private void drawPerformance(GuiGraphics g) {
        title(g, "Rendimiento", "Ajustes rápidos pensados para jugar más estable.");
        int y = panelY + 62;
        switchRow(g, y, "FPS Boost", "Aplica los ajustes de rendimiento del cliente.", BoxConfig.boost);
        switchRow(g, y + 46, "Sin partículas", "Limpia partículas para reducir carga visual.", BoxConfig.noParticles);
        switchRow(g, y + 92, "30 FPS sin foco", "Limita FPS cuando Minecraft queda en segundo plano.", BoxConfig.bgThrottle);
        g.drawString(this.font, Component.literal("Estado"), panelX + 176, y + 152, accent());
        g.drawString(this.font, Component.literal(BoxConfig.boost ? "VoidX Boost está activo." : "VoidX Boost está desactivado."), panelX + 176, y + 169, WHITE);
    }

    private void drawHud(GuiGraphics g) {
        title(g, "HUD", "Información limpia y un editor visual sin widgets vanilla.");
        int y = panelY + 62;
        switchRow(g, y, "HUD principal", "Muestra el HUD de VoidX.", BoxConfig.hud);
        switchRow(g, y + 46, "CPS", "Contador de clics por segundo.", BoxConfig.cps);
        switchRow(g, y + 92, "FPS", "Muestra los FPS actuales.", BoxConfig.fps);
        switchRow(g, y + 138, "Ping", "Muestra la latencia del servidor.", BoxConfig.ping);
        switchRow(g, y + 184, "Armadura", "Muestra el estado de la armadura.", BoxConfig.armor);
        drawButton(g, panelX + 176, y + 230, 150, 30, "Edit HUD", mouseX, mouseY, accent());
        g.drawString(this.font, Component.literal("Posición: " + BoxConfig.hudX + ", " + BoxConfig.hudY + "   Escala: " + BoxConfig.hudScale + "%"), panelX + 336, y + 240, MUTED);
    }

    private void drawGui(GuiGraphics g) {
        title(g, "Gui", "Personaliza VoidX sin meter animaciones pesadas.");
        int y = panelY + 62;
        switchRow(g, y, "Bordes", "Marco limpio alrededor del panel.", BoxConfig.guiBorder);
        switchRow(g, y + 46, "Glow", "Brillo ligero detrás del panel.", BoxConfig.guiGlow);
        switchRow(g, y + 92, "Rainbow", "Acento de color animado de bajo coste.", BoxConfig.guiRainbow);
        switchRow(g, y + 138, "HUD Rainbow", "Acento rainbow también para el HUD.", BoxConfig.hudRainbow);

        int x = panelX + 176;
        int w = panelW - 194;
        int cy = y + 190;
        g.fill(x, cy, x + w, cy + 78, CARD);
        g.drawString(this.font, Component.literal("Tamaño de GUI"), x + 12, cy + 10, WHITE);
        drawButton(g, x + 12, cy + 31, 72, 28, "−", mouseX, mouseY, accent());
        g.drawCenteredString(this.font, Component.literal(BoxConfig.guiScale + "%"), x + 122, cy + 39, WHITE);
        drawButton(g, x + 168, cy + 31, 72, 28, "+", mouseX, mouseY, accent());
        g.drawString(this.font, Component.literal("Opacidad: " + BoxConfig.guiOpacity + "%"), x + 260, cy + 15, MUTED);
        drawButton(g, x + 260, cy + 34, 70, 25, "−", mouseX, mouseY, accent());
        drawButton(g, x + 338, cy + 34, 70, 25, "+", mouseX, mouseY, accent());
    }

    private void drawUtilities(GuiGraphics g) {
        title(g, "Utilidades", "Pequeñas funciones para PvP y movilidad.");
        int y = panelY + 62;
        switchRow(g, y, "Firework Fixed", "Ajuste de uso de fuegos artificiales mientras vuelas.", BoxConfig.fireworkFix);
        g.fill(panelX + 176, y + 62, panelX + panelW - 18, y + 124, CARD);
        g.drawString(this.font, Component.literal("Tecla de menú"), panelX + 188, y + 74, accent());
        g.drawString(this.font, Component.literal("1"), panelX + 188, y + 91, WHITE);
        g.drawString(this.font, Component.literal("Puedes cambiarla desde Controls > Key Binds."), panelX + 188, y + 107, MUTED);
    }

    private void drawSettings(GuiGraphics g) {
        title(g, "Ajustes", "Información del cliente y acciones rápidas.");
        int x = panelX + 176;
        int y = panelY + 62;
        g.fill(x, y, x + panelW - 194, y + 72, CARD);
        g.drawString(this.font, Component.literal("VoidX Client"), x + 14, y + 12, WHITE);
        g.drawString(this.font, Component.literal("Minecraft 1.21.11  •  Fabric"), x + 14, y + 29, MUTED);
        g.drawString(this.font, Component.literal("Panel medio • fondo del mundo visible"), x + 14, y + 46, MUTED);
        drawButton(g, x, y + 88, 170, 34, "Cerrar VoidX", mouseX, mouseY, accent());
    }

    private void drawButton(GuiGraphics g, int x, int y, int w, int h, String text, int mx, int my, int a) {
        boolean hover = inside(mx, my, x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? 0xFF3A3044 : 0xFF211C27);
        g.fill(x, y, x + w, y + 1, a);
        g.drawCenteredString(this.font, Component.literal(text), x + w / 2, y + 10, WHITE);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        drawPanel(g);
        switch (tab) {
            case 0 -> drawHome(g);
            case 1 -> drawPerformance(g);
            case 2 -> drawHud(g);
            case 3 -> drawGui(g);
            case 4 -> drawUtilities(g);
            default -> drawSettings(g);
        }
        int a = accent();
        int pulse = (int) ((Math.sin(System.currentTimeMillis() / 260.0) + 1.0) * 12);
        g.fill(panelX + 176, panelY + panelH - 9, panelX + 250 + pulse, panelY + panelH - 7, a);
        g.drawString(this.font, Component.literal("● ONLINE"), panelX + panelW - 76, panelY + panelH - 22, GREEN);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();
        int sideW = 154;

        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 58 + i * 40;
            if (inside(mx, my, panelX + 10, y, sideW - 20, 32)) {
                tab = i;
                return true;
            }
        }

        int x = panelX + 176;
        int w = panelW - 194;
        int y = panelY + 62;

        if (tab == 1) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.boost = !BoxConfig.boost;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.noParticles = !BoxConfig.noParticles;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.bgThrottle = !BoxConfig.bgThrottle;
            else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 2) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.hud = !BoxConfig.hud;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.cps = !BoxConfig.cps;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.fps = !BoxConfig.fps;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.ping = !BoxConfig.ping;
            else if (inside(mx, my, x, y + 184, w, 38)) BoxConfig.armor = !BoxConfig.armor;
            else if (inside(mx, my, x, y + 230, 150, 30)) {
                Minecraft.getInstance().setScreen(new HudEditorScreen());
                return true;
            } else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 3) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.guiBorder = !BoxConfig.guiBorder;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.guiGlow = !BoxConfig.guiGlow;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.guiRainbow = !BoxConfig.guiRainbow;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.hudRainbow = !BoxConfig.hudRainbow;
            else {
                int cy = y + 190;
                if (inside(mx, my, x + 12, cy + 31, 72, 28)) BoxConfig.guiScale = Math.max(85, BoxConfig.guiScale - 5);
                else if (inside(mx, my, x + 168, cy + 31, 72, 28)) BoxConfig.guiScale = Math.min(115, BoxConfig.guiScale + 5);
                else if (inside(mx, my, x + 260, cy + 34, 70, 25)) BoxConfig.guiOpacity = Math.max(55, BoxConfig.guiOpacity - 5);
                else if (inside(mx, my, x + 338, cy + 34, 70, 25)) BoxConfig.guiOpacity = Math.min(100, BoxConfig.guiOpacity + 5);
                else return super.mouseClicked(event, doubleClick);
                BoxConfig.save();
                this.init();
                return true;
            }
            BoxConfig.save();
            return true;
        }
        if (tab == 4 && inside(mx, my, x, y, w, 38)) {
            BoxConfig.fireworkFix = !BoxConfig.fireworkFix;
            BoxConfig.save();
            return true;
        }
        if (tab == 5 && inside(mx, my, x, y + 88, 170, 34)) {
            onClose();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }
}
