package com.luiscript.boxpvp;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public final class BoxMenuScreen extends Screen {
    private static final int PURPLE = 0xFF9B4DFF;
    private static final int PURPLE_BRIGHT = 0xFFC48CFF;
    private static final int WHITE = 0xFFF4F0FF;
    private static final int MUTED = 0xFFAAA3B8;
    private static final int PANEL = 0xF20B0B0F;
    private static final int PANEL_2 = 0xF516141B;
    private static final int CARD = 0xE61A1720;
    private static final int CARD_HOVER = 0xF3262030;
    private static final int GREEN = 0xFF65E6A5;
    private static final int RED = 0xFFFF6B7A;

    private int panelX, panelY, panelW, panelH;
    private int tab = 0;
    private static final String[] TABS = {"Inicio", "Rendimiento", "HUD", "Utilidades", "Ajustes"};

    public BoxMenuScreen() {
        super(Component.literal("VoidX Client"));
    }

    @Override
    protected void init() {
        panelW = Math.min(660, this.width - 24);
        panelH = Math.min(390, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
    }

    private boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void toggle(String name, String desc, boolean value) {
        // Draw-only toggle; clicks are handled in mouseClicked().
    }

    private void drawPanel(GuiGraphics g) {
        // Soft purple glow around the medium floating panel.
        g.fill(panelX - 2, panelY - 2, panelX + panelW + 2, panelY + panelH + 2, 0x559B4DFF);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, PANEL);
        g.fill(panelX, panelY, panelX + 2, panelY + panelH, PURPLE);
        g.fill(panelX, panelY, panelX + panelW, panelY + 1, 0xFF3A284C);

        int sideW = 154;
        g.fill(panelX + sideW, panelY + 1, panelX + sideW + 1, panelY + panelH - 1, 0xFF2A2432);

        // Decorative corner accents.
        g.fill(panelX + panelW - 24, panelY + 12, panelX + panelW - 10, panelY + 14, PURPLE);
        g.fill(panelX + panelW - 14, panelY + 18, panelX + panelW - 10, panelY + 32, PURPLE);

        g.drawString(this.font, Component.literal("VOIDX"), panelX + 18, panelY + 18, WHITE);
        g.drawString(this.font, Component.literal("CLIENT"), panelX + 19, panelY + 30, PURPLE_BRIGHT);
        g.drawString(this.font, Component.literal("KEY 1"), panelX + 101, panelY + 24, MUTED);

        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 62 + i * 43;
            boolean selected = tab == i;
            boolean hover = inside(mouseX, mouseY, panelX + 10, y, sideW - 20, 34);
            int bg = selected ? 0xCC5520A0 : hover ? 0x993A3044 : 0x66120F17;
            g.fill(panelX + 10, y, panelX + sideW - 10, y + 34, bg);
            if (selected) g.fill(panelX + 10, y, panelX + 13, y + 34, PURPLE);
            drawTabIcon(g, panelX + 25, y + 17, i, selected ? PURPLE_BRIGHT : MUTED);
            g.drawString(this.font, Component.literal(TABS[i]), panelX + 40, y + 11, selected ? WHITE : MUTED);
        }

        g.drawString(this.font, Component.literal("VOIDX  •  1.0"), panelX + 17, panelY + panelH - 22, MUTED);
    }

    private void drawTabIcon(GuiGraphics g, int x, int y, int index, int color) {
        String icon = switch (index) {
            case 0 -> "◆";
            case 1 -> "⚡";
            case 2 -> "◇";
            case 3 -> "✦";
            default -> "⚙";
        };
        g.drawCenteredString(this.font, Component.literal(icon), x, y - 5, color);
    }

    private void title(GuiGraphics g, String name, String subtitle) {
        int x = panelX + 176;
        g.drawString(this.font, Component.literal(name), x, panelY + 20, WHITE);
        g.drawString(this.font, Component.literal(subtitle), x, panelY + 34, MUTED);
    }

    private void card(GuiGraphics g, int x, int y, int w, int h, String name, String desc, boolean active) {
        boolean hover = inside(mouseX, mouseY, x, y, w, h);
        g.fill(x, y, x + w, y + h, hover ? CARD_HOVER : CARD);
        g.fill(x, y, x + 3, y + h, active ? PURPLE : 0xFF3A3440);
        g.drawString(this.font, Component.literal(name), x + 13, y + 9, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 13, y + 23, MUTED);
        if (active) g.drawString(this.font, Component.literal("ON"), x + w - 32, y + 9, GREEN);
        else g.drawString(this.font, Component.literal("OFF"), x + w - 36, y + 9, RED);
    }

    private void switchRow(GuiGraphics g, int y, String name, String desc, boolean value) {
        int x = panelX + 176;
        int w = panelW - 194;
        boolean hover = inside(mouseX, mouseY, x, y, w, 38);
        g.fill(x, y, x + w, y + 38, hover ? CARD_HOVER : CARD);
        g.drawString(this.font, Component.literal(name), x + 12, y + 7, WHITE);
        g.drawString(this.font, Component.literal(desc), x + 12, y + 21, MUTED);
        int sx = x + w - 50;
        int sy = y + 10;
        int color = value ? PURPLE : 0xFF39343F;
        g.fill(sx, sy, sx + 34, sy + 17, color);
        g.fill(value ? sx + 20 : sx + 3, sy + 3, value ? sx + 31 : sx + 14, sy + 14, WHITE);
    }

    private void drawHome(GuiGraphics g) {
        title(g, "Bienvenido a VoidX", "Tu panel de utilidades dentro del mundo, sin pantalla vanilla gigante.");
        int x = panelX + 176;
        int y = panelY + 62;
        g.fill(x, y, x + panelW - 194, y + 76, 0xD9161020);
        g.fill(x, y, x + 4, y + 76, PURPLE);
        g.drawString(this.font, Component.literal("VOIDX"), x + 16, y + 14, PURPLE_BRIGHT);
        g.drawString(this.font, Component.literal("PLAY DIFFERENT"), x + 16, y + 30, WHITE);
        g.drawString(this.font, Component.literal("Optimización + HUD + utilidades"), x + 16, y + 50, MUTED);
        g.drawString(this.font, Component.literal("◆"), x + panelW - 225, y + 20, PURPLE_BRIGHT);

        int cw = (panelW - 206) / 3;
        int cy = y + 90;
        card(g, x, cy, cw, 56, "FPS Boost", "Rendimiento", BoxConfig.boost);
        card(g, x + cw + 8, cy, cw, 56, "HUD", "Información", BoxConfig.hud);
        card(g, x + (cw + 8) * 2, cy, cw, 56, "Particles", "Limpieza", BoxConfig.noParticles);

        g.drawString(this.font, Component.literal("Consejo"), x, cy + 78, PURPLE_BRIGHT);
        g.drawString(this.font, Component.literal("Usa los botones laterales para cambiar de sección."), x, cy + 94, MUTED);
    }

    private void drawPerformance(GuiGraphics g) {
        title(g, "Rendimiento", "Ajustes rápidos pensados para jugar más estable.");
        int y = panelY + 62;
        switchRow(g, y, "FPS Boost", "Aplica los ajustes de rendimiento del cliente.", BoxConfig.boost);
        switchRow(g, y + 46, "Sin partículas", "Limpia partículas para reducir carga visual.", BoxConfig.noParticles);
        switchRow(g, y + 92, "30 FPS sin foco", "Limita FPS cuando Minecraft queda en segundo plano.", BoxConfig.bgThrottle);
        g.drawString(this.font, Component.literal("Estado"), panelX + 176, y + 152, PURPLE_BRIGHT);
        g.drawString(this.font, Component.literal(BoxConfig.boost ? "VoidX Boost está activo." : "VoidX Boost está desactivado."), panelX + 176, y + 169, WHITE);
    }

    private void drawHud(GuiGraphics g) {
        title(g, "HUD", "Elige exactamente qué información quieres ver en pantalla.");
        int y = panelY + 62;
        switchRow(g, y, "HUD principal", "Muestra el HUD de VoidX.", BoxConfig.hud);
        switchRow(g, y + 46, "CPS", "Contador de clics por segundo.", BoxConfig.cps);
        switchRow(g, y + 92, "FPS", "Muestra los FPS actuales.", BoxConfig.fps);
        switchRow(g, y + 138, "Ping", "Muestra la latencia del servidor.", BoxConfig.ping);
        switchRow(g, y + 184, "Armadura", "Muestra el estado de la armadura.", BoxConfig.armor);
    }

    private void drawUtilities(GuiGraphics g) {
        title(g, "Utilidades", "Pequeñas funciones para PvP y movilidad.");
        int y = panelY + 62;
        switchRow(g, y, "Firework Fixed", "Ajuste de uso de fuegos artificiales mientras vuelas.", BoxConfig.fireworkFix);
        g.fill(panelX + 176, y + 62, panelX + panelW - 18, y + 124, CARD);
        g.drawString(this.font, Component.literal("Tecla de menú"), panelX + 188, y + 74, PURPLE_BRIGHT);
        g.drawString(this.font, Component.literal("1"), panelX + 188, y + 91, WHITE);
        g.drawString(this.font, Component.literal("Puedes cambiarla desde Controls > Key Binds."), panelX + 188, y + 107, MUTED);
    }

    private void drawSettings(GuiGraphics g) {
        title(g, "Ajustes", "Información del cliente y acciones rápidas.");
        int x = panelX + 176;
        int y = panelY + 62;
        g.fill(x, y, x + panelW - 194, y + 72, CARD);
        g.drawString(this.font, Component.literal("VoidX Client"), x + 14, y + 12, WHITE);
        g.drawString(this.font, Component.literal("Minecraft 1.21.11  •  Fabric"), x + 14, y + 29, MUTED);
        g.drawString(this.font, Component.literal("Panel medio • fondo del mundo visible"), x + 14, y + 46, MUTED);

        boolean hover = inside(mouseX, mouseY, x, y + 88, 170, 34);
        g.fill(x, y + 88, x + 170, y + 122, hover ? 0xFF3A3044 : 0xFF211C27);
        g.drawCenteredString(this.font, Component.literal("Cerrar VoidX"), x + 85, y + 99, WHITE);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // Screen.render keeps Minecraft's in-world background visible behind our floating panel.
        super.render(g, mouseX, mouseY, delta);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        drawPanel(g);
        switch (tab) {
            case 0 -> drawHome(g);
            case 1 -> drawPerformance(g);
            case 2 -> drawHud(g);
            case 3 -> drawUtilities(g);
            default -> drawSettings(g);
        }

        // Tiny animated-looking accent bars; cheap to render.
        int pulse = (int) ((Math.sin(System.currentTimeMillis() / 260.0) + 1.0) * 18);
        g.fill(panelX + 176, panelY + panelH - 9, panelX + 250 + pulse, panelY + panelH - 7, 0xFF6E35A8);
        g.drawString(this.font, Component.literal("● ONLINE"), panelX + panelW - 76, panelY + panelH - 22, GREEN);
    }

    private int mouseX;
    private int mouseY;

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() != 0) return super.mouseClicked(event, doubleClick);
        double mx = event.x();
        double my = event.y();

        int sideW = 154;
        for (int i = 0; i < TABS.length; i++) {
            int y = panelY + 62 + i * 43;
            if (inside(mx, my, panelX + 10, y, sideW - 20, 34)) {
                tab = i;
                return true;
            }
        }

        int x = panelX + 176;
        int w = panelW - 194;
        int y = panelY + 62;

        if (tab == 1) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.boost = !BoxConfig.boost;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.noParticles = !BoxConfig.noParticles;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.bgThrottle = !BoxConfig.bgThrottle;
            else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 2) {
            if (inside(mx, my, x, y, w, 38)) BoxConfig.hud = !BoxConfig.hud;
            else if (inside(mx, my, x, y + 46, w, 38)) BoxConfig.cps = !BoxConfig.cps;
            else if (inside(mx, my, x, y + 92, w, 38)) BoxConfig.fps = !BoxConfig.fps;
            else if (inside(mx, my, x, y + 138, w, 38)) BoxConfig.ping = !BoxConfig.ping;
            else if (inside(mx, my, x, y + 184, w, 38)) BoxConfig.armor = !BoxConfig.armor;
            else return super.mouseClicked(event, doubleClick);
            BoxConfig.save();
            return true;
        }
        if (tab == 3) {
            if (inside(mx, my, x, y, w, 38)) {
                BoxConfig.fireworkFix = !BoxConfig.fireworkFix;
                BoxConfig.save();
                return true;
            }
        }
        if (tab == 4 && inside(mx, my, x, y + 88, 170, 34)) {
            onClose();
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }
}
