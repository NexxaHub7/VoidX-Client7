# VoidX Client Key 1

VoidX Client for Minecraft 1.21.11 + Fabric.

## GUI
- Opens with key `1`.
- Medium floating black/purple panel centered over the Minecraft world.
- Custom-drawn tabs instead of vanilla Minecraft buttons.
- Tabs: Inicio, Rendimiento, HUD, Utilidades, Ajustes.
- Purple hover/selection effects and lightweight animated accents.
- The in-world Minecraft background remains visible behind the panel.

## Features
- FPS Boost
- Particle clearing
- Background FPS throttle
- CPS / FPS / Ping / Armor HUD
- Firework Fixed
- Config saved to `boxpvp_utils.properties`
